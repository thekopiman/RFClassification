from . import (
    cifar_resnet, densenet, my_resnet, my_resnet_importance, my_resnet2, my_resnet_brn, my_resnet_mcbn, my_resnet_mtl,
    resnet, resnet_importance, resnet_mtl, ucir_resnet, vgg
)
