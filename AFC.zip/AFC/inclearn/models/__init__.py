# flake8: noqa
from .base import IncrementalLearner
from .icarl import ICarl
from .afc import AFC
